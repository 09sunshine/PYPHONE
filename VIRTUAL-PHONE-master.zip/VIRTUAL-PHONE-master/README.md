# Virtual-Phone
Python Minor Project - BCA 5TH SEMESTER

VIRTUAL PHONE

This project ‘VIRTUAL PHONE’ helps us to perform few of the basic functionalities of a mobile phone. It can mainly be used as a substitute of a mobile phone for specific modules.
Over the internet, if we analyze, we will not get an application like this which performs the basic tasks of a phone in desktop environment. Keeping this in mind, we are trying to implement an application which can do few of the basic tasks very easily. In our application we can do the following tasks:
	Send free SMS.
	Send free voice messages
	Send emails
	Store and Backup contacts
	Browse the internet using the Browser
	Write and save notes 
	Make basic calculations using the Calculator 
	Have access to the Calendar
	Get to know the present weather conditions using the Weather app. 




TEAM: SUMAN KANRAR, SANWAYA DATTA, SANJANA MONDAL, PRIYANKA SAHA

